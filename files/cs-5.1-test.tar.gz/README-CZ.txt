cs-5.0.tar.gz
-------------

Toto je cesky preklad pro Drupal verze 5.0.
Obsahuje:
- Cesky preklad instalace a rozhrani
- Modul pathauto pro automaticke generovani cest

Instalace
---------
a) Jdu delat cistou instalaci Drupal 5.0
   Pouzijte instalacni profil na adrese http://www.drupal.cz/ke-stazeni
   Stahnete Drupal 5.0 na adrese http://www.drupal.org

   Rozbalte Drupal 5.0, vznikne Vam adresar drupal-5.0
   Instalacni profil cs-5.0.tar.gz nakopirujte do tohoto adresare a pote
   rozbalte. Instalacni profil doplni nektere soubory, zadne vsak nemaze.
   Nedelejte to ani vy.

   POZOR! Instalacni profil opravdu obsahuje 100% prekladu vsech zakladnich
   modulu, pri instalaci se vsak prelozi pouze ty, ktere jsou v te chvili
   zapnute. Pokud zapnete nejaky dalsi modul (treba blog), je treba jit na
   Administrace -> Lokalizace -> Auto import a tam importovat preklad.

   Cely adresar nahrajte na Vas webhosting a pokracujte v instalaci
   nasmerovanim prohlizece na prislusnou adresu.

   Po instalaci je nutne podivat se na Administrace -> Pathauto a zde ulozit
   nastaveni, jinak se nebudou spravne ukladat URL.

   Pokud chcete pouzivat ciste URL, nezapomente se podivat do souboru .htaccess
   a odkomentovat radku RewriteBase, kde vyplnte adresar, s cestou k
   nainstalovanemu Drupalu. Pokud mate napr. Drupal nainstalovan v ceste
   http://www.domena.cz/, dejte /, pokud http://www.domena.cz/drupal, dejte
   /drupal

b) Jiz mam Drupal 5.0 nainstalovany
   Pridejjte jazyk Czech a importujte soubor cs.po, ktery naleznete na adrese
   http://www.drupal.org/project/cs - V TOMTO PRIPADE NEPOUZIVEJTE TENTO
   INSTALACNI PROFIL


S problemy se obracejte na forum Drupal CZ na adrese http://www.drupal.cz

Copyright
---------
(C) Copyright 2007 Jakub Suchy <redakce@drupal.cz>
Licencovano pod licenci GNU/GPL verze 2.

